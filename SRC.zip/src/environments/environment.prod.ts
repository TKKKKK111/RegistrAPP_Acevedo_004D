export const environment = {
  production: true,
  apiKey: 'fc7d9914898440dbbd18848dcadd6851'

};

