import { Component, OnInit } from '@angular/core';
import { AlertController } from '@ionic/angular';
import { RegistroserviceService, Usuario } from '../service/registroservice.service';
import { ToastController } from '@ionic/angular';
import { AbstractControl, ReactiveFormsModule } from '@angular/forms';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';



@Component({
  selector: 'app-registro-docente',
  templateUrl: './registro-docente.page.html',
  styleUrls: ['./registro-docente.page.scss'],
})

export class RegistroDocentePage implements OnInit {
  ps='[=)(-.';
  formularioRegistro : FormGroup;
  newRegistro: Usuario = <Usuario>{};
  f : Usuario[] = [];

  constructor(private alertController: AlertController, 
              private registroService: RegistroserviceService, 
              private toastController: ToastController, 
              private fb: FormBuilder) { 
                  this.formularioRegistro = fb.group({ 
                    'nombre' : new FormControl("", [Validators.required,Validators.minLength(3), Validators.maxLength(20)]),
                    'correo' : new FormControl("", [Validators.required,Validators.email]),
                    'password': new FormControl("", [Validators.required,Validators.minLength(8),]),
                    'confirmaPass': new FormControl("",[Validators.required,Validators.minLength(8),Validators.maxLength(16)])
                  }, {validator: this.checkIfMatchingPasswords('password', 'confirmaPass')})
               }


               nm= (/[A-Za-z]\w/);
  ngOnInit() {
  }
/// VER PASSWORD 
  checkIfMatchingPasswords(passwordKey: string , passConfirmKey: string){
    return (group: FormGroup) =>{
      let passwordInput = group.controls[passwordKey],
      passConfirmInput = group.controls[passConfirmKey];
      if ( passwordInput.value !== passConfirmInput.value){
        return passConfirmInput.setErrors({notEquivalent: true})
      }
      else{
        return passConfirmInput.setErrors(null);
      }
    }

  }
  psv='^(?=.*=[A-Z])(?=.*?[a.z])(?=-*?[0-9]).{8.16}$'






  async CrearUsuario(){
    var form = this.formularioRegistro.value;
    if(this.formularioRegistro.invalid){
      const alert = await this.alertController.create({
        header : 'Datos Incorrectos...', 
        message: 'Por favor verificar datos.', 
        buttons: ['Aceptar']
      })
      await alert.present();
      return;
    }
    //Correo existente
    var datos = await this.registroService.getUsuarios();
    if (datos && datos.length>0){
      for (let obj of datos){
        if (obj.correoUsuario == form.correo){
          const alert = await this.alertController.create({
            header : 'Correo existente...',
            message: 'Por favor verificar correo.',
            buttons: ['Aceptar']
          })
          await alert.present();
          return;
        }
      }
    }
    //Crear usuario
    this.newRegistro.nomUsuario = form.nombre;
    this.newRegistro.correoUsuario = form.correo;
    this.newRegistro.passUsuario = form.password;

    this.registroService.addUsuario(this.newRegistro);
    await this.registroService.addUsuario(this.newRegistro);

    const toast = await this.toastController.create({
      message: 'Usuario creado correctamente.',
      duration: 2000
    });
    toast.present();
    this.formularioRegistro.reset();
  }
}



    
      

    


  
