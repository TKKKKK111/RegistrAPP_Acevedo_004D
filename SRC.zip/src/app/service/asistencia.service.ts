import { Injectable } from '@angular/core';
import { Storage } from '@ionic/storage-angular';

export interface Asistencia {
  nombre: string;
  correo: string;
  seccion: string;
  asistencia: string;
  fecha: string;

}

const ASIST = 'ASISTENCIA';

@Injectable({
  providedIn: 'root'
})
export class AsistenciaService {


  private _storage : Storage;
  constructor(private storage : Storage) { }

  async init(){
    const storage = await this.storage.create();
    this._storage = storage;  
  }

  async addAsistencia(dato: Asistencia):Promise<any>{
    return this.storage.get(ASIST).then((datos: Asistencia[])=>{
      if (datos){
          datos.push(dato);
          return this.storage.set(ASIST, datos);
      }
      else{
        return this.storage.set(ASIST, [dato]);
      }
     })


     
  




}

async getAsist(){
  return this.storage.get(ASIST);
}
}
