import { Component, OnInit } from '@angular/core';
import { Usuario } from '../service/registroservice.service';


@Component({
  selector: 'app-recuperar',
  templateUrl: './recuperar.page.html',
  styleUrls: ['./recuperar.page.scss'],
})
export class RecuperarPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }


   
}
