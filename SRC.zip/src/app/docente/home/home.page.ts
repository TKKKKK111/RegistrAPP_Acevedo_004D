import { Component, OnInit } from '@angular/core';
import { AlertController, NavController } from '@ionic/angular';


@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
})
export class HomePage implements OnInit {

  constructor(public navCtrl: NavController, public alertController : AlertController) { }

  ngOnInit() {
  }

   async exit(){
    const alerta= await this.alertController.create({
      header: 'Gracias por visitarnos!',
      buttons:['ok'],
      mode:'ios'
    })
    await alerta.present();
    localStorage.removeItem('ingresado');
    this.navCtrl.navigateRoot('/pantalla1');

    
  


    
  }
    async d() { 
      this.navCtrl.navigateRoot('/qr')
    }
    async f (){
      this.navCtrl.navigateRoot('/camara')
    }
}
