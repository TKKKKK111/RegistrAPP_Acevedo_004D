import { Component, OnInit } from '@angular/core';
import { DatosService, Estudiante } from '../../datos.service';
import { RegistroEstudiantesPage } from '../../registro-estudiantes/registro-estudiantes.page';


@Component({
  selector: 'app-generador-qr',
  templateUrl: './generador-qr.page.html',
  styleUrls: ['./generador-qr.page.scss'],
})
export class GeneradorQRPage implements OnInit {

  qrCodeString= 'Hola Mundo'; 



  constructor() { }

  ngOnInit() {
  }


  usuario={
    nom:'',
  }

  generaScan(){
    this.qrCodeString= this.usuario.nom;
  }





}
