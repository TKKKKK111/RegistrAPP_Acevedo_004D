import { Component, OnInit } from '@angular/core';
import { BarcodeScanner } from '@capacitor-community/barcode-scanner'
import { AlertController } from '@ionic/angular';
import { Router } from '@angular/router';
import { alertController } from '@ionic/core';

@Component({
  selector: 'app-qr-scanner',
  templateUrl: './qr-scanner.page.html',
  styleUrls: ['./qr-scanner.page.scss'],
})
export class QrScannerPage implements OnInit {

  result = null;
  scanActivate= false;


  constructor( private alertController : AlertController) { }

  ngOnInit() {
    BarcodeScanner.prepare();

  }
  ngOnDestroy(){
    BarcodeScanner.stopScan();
  }

 async startScaner(){
   const allowed = await this.checkPermission();
   if (allowed){
    this.scanActivate = true;
    const result = await BarcodeScanner.startScan();
    console.log('Resultadooo', result);
    if (result.hasContent){
      this.result = result.content;
      this.scanActivate = false;
      BarcodeScanner.stopScan();
    }
  }
   
  }



  async checkPermission(){
    return new Promise(async (resolve, reject) => {
      const status = await BarcodeScanner.checkPermission({ force: true });
      if (status.granted) {
        return resolve(true);
      }
      else if (status.denied){
        const alert = await alertController.create({
          header: 'Permisos',
          message: 'No se pueden escanear códigos de barras sin permisos',
          buttons: [
            {
              text: 'Cancelar',
              role: 'cancel',
            },
            { text: 'Abrir configuración', handler: () =>{ 
              BarcodeScanner.openAppSettings() ;
              resolve(false);
            
            }
          }]
        });
        await alert.present();


      } else { 

        resolve(false);
      }

    
     
      
    



    })



  }
  stopScanner(){
    this.scanActivate = false;
    BarcodeScanner.stopScan();
  }
}






