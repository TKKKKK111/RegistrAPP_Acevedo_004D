import { Component, OnInit } from '@angular/core';
import { AlertController, NavController } from '@ionic/angular';


@Component({
  selector: 'app-inicio',
  templateUrl: './inicio.page.html',
  styleUrls: ['./inicio.page.scss'],
})
export class InicioPage implements OnInit {

 

 
 
 constructor(public navCtrl: NavController, public alertController : AlertController) { }

  ngOnInit() {
  }

   async exit(){
    const alerta= await this.alertController.create({
      header: '¡Vuelve Pronto!',
      buttons:['ok'],
      mode:'ios'
    })
    await alerta.present();
    localStorage.removeItem('ingresado');
    localStorage.removeItem('Fecha');
    localStorage.removeItem('Asistencia');
    this.navCtrl.navigateRoot('/pantalla1');

    
  


    
  }

  
}
