import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CamaraQRPageRoutingModule } from './camara-qr-routing.module';

import { CamaraQRPage } from './camara-qr.page';


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CamaraQRPageRoutingModule
  ],
  declarations: [CamaraQRPage]
})
export class CamaraQRPageModule {}
