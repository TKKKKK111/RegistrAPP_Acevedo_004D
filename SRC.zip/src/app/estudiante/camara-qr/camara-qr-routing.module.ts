import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CamaraQRPage } from './camara-qr.page';

const routes: Routes = [
  {
    path: '',
    component: CamaraQRPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CamaraQRPageRoutingModule {}
