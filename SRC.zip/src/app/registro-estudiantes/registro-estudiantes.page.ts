
import { Component, OnInit } from '@angular/core';
import { AlertController } from '@ionic/angular';
import { DatosService,Estudiante } from '../datos.service';
import { ToastController } from '@ionic/angular';
import { FormGroup, FormControl, FormBuilder, Validators,ReactiveFormsModule } from '@angular/forms';
import { of } from 'rxjs';


@Component({
  selector: 'app-registro-estudiantes',
  templateUrl: './registro-estudiantes.page.html',
  styleUrls: ['./registro-estudiantes.page.scss'],
})
export class RegistroEstudiantesPage implements OnInit {

  f : Estudiante[] = [];
  formularioR : FormGroup;
  newRegistre: Estudiante = <Estudiante>{};

  constructor(private alertController: AlertController, 
              private registroService: DatosService, 
              private toastController: ToastController, 
              private fb: FormBuilder) { 
                  this.formularioR = fb.group({ 
                    'usuario': new FormControl("",[Validators.required,Validators.minLength(8),Validators.maxLength(15)]),
                    'nombre': new FormControl ("",[Validators.required,Validators.minLength(3),Validators.maxLength(20)]),
                    'correo' : new FormControl("", [Validators.required,Validators.email]),
                    'password': new FormControl("", [Validators.required,Validators.minLength(6),Validators.maxLength(18)]),
                    'confirmaPass': new FormControl("",[Validators.required,Validators.minLength(6),Validators.maxLength(18)])},
                    {validator: this.checkIfMatchingPasswords('password', 'confirmaPass')})
               }

               mailv=(/^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)
               nm= (/[A-Za-z]\w/);
               us=(/([A-Za-z1-9])\w/g)
               ngOnInit() {
               }
             /// VER PASSWORD 
               checkIfMatchingPasswords(passwordKey: string , passConfirmKey: string){
                 return (group: FormGroup) =>{
                   let passwordInput = group.controls[passwordKey],
                   passConfirmInput = group.controls[passConfirmKey];
                   if ( passwordInput.value !== passConfirmInput.value){
                     return passConfirmInput.setErrors({notEquivalent: true})
                   }
                   else{
                     return passConfirmInput.setErrors(null);
                   }
                 }
             
               }
               psv='^(?=.*=[A-Z])(?=.*?[a.z])(?=-*?[0-9]).{8.16}$'
             
             
             

  async CrearUsuario(){
    var form = this.formularioR.value;
    if(this.formularioR.invalid){
      const alert = await this.alertController.create({
        header : 'Error..', 
        message: 'Debe ingresar todos los datos', 
        buttons: ['Aceptar']
      })
      await alert.present();
      return;
      

      
    

    }   
// Validar que el usuario no exista
          
  //Correo existente
  var datos = await this.registroService.getUsuarios();
  if (datos && datos.length>0){
    for (let obj of datos){
      if (obj.correoEstudiante == form.correo && obj.usuarioEstudiante == form.usuario){
        const alert = await this.alertController.create({
          header : 'Correo existente...',
          message: 'Por favor verificar correo.',
          buttons: ['Aceptar']
        })
        await alert.present();
        return;
      }
    }
  }
  //Crear usuario
  this.newRegistre.userEstudiante = form.usuario;
  this.newRegistre.nomEstudiante = form.nombre;
  this.newRegistre.correoEstudiante = form.correo;
  this.newRegistre.passEstudiante = form.password;
  this.newRegistre.repassEstudiante= form.confirmaPass;



  this.registroService.addUsuario(this.newRegistre);
  await this.registroService.addUsuario(this.newRegistre);

  const toast = await this.toastController.create({
    message: 'Usuario creado correctamente.',
    duration: 2000
  });
  toast.present();
  this.formularioR.reset();
}
}



  
    

  

