import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { RegistroEstudiantesPageRoutingModule } from './registro-estudiantes-routing.module';

import { RegistroEstudiantesPage } from './registro-estudiantes.page';
import { ReactiveFormsModule } from '@angular/forms';
@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    IonicModule,
    RegistroEstudiantesPageRoutingModule
  ],
  declarations: [RegistroEstudiantesPage]
})
export class RegistroEstudiantesPageModule {}
