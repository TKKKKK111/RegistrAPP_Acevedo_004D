import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pantalla1',
  templateUrl: './pantalla1.page.html',
  styleUrls: ['./pantalla1.page.scss'],
})
export class Pantalla1Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
