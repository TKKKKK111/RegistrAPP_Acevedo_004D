import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { IngresadoGuard } from './ingresado.guard';
import { NoIngresadoGuard } from './no-ingresado.guard';
import { IngresadoEstudianteGuard } from './ingresado-estudiante.guard';

const routes: Routes = [

  {
    path: '',
    redirectTo: 'pantalla1',
    pathMatch: 'full'
  },
  {path: 'estudiante/inicio',loadChildren: () => import('./estudiante/inicio/inicio.module').then( m => m.InicioPageModule)


  
    
  },
  {
    path: 'login',
    loadChildren: () => import('./login/login.module').then( m => m.LoginPageModule)
  },
  {
    path: 'login-docente',
    loadChildren: () => import('./login-docente/login-docente.module').then( m => m.LoginDocentePageModule)
    

  },
  {
    path: 'pantalla1',
    loadChildren: () => import('./pantalla1/pantalla1.module').then( m => m.Pantalla1PageModule)
    
  },
  
  {
    path: 'registro-docente',
    loadChildren: () => import('./registro-docente/registro-docente.module').then( m => m.RegistroDocentePageModule)
  
   
  },
  {
    path: 'docente/home',
    loadChildren: () => import('./docente/home/home.module').then( m => m.HomePageModule)
 
  },
  {
    path: 'registro-estudiantes',
    loadChildren: () => import('./registro-estudiantes/registro-estudiantes.module').then( m => m.RegistroEstudiantesPageModule)
  },
  {
    path: 'camara',
    loadChildren: () => import('./estudiante/camara-qr/camara-qr.module').then( m => m.CamaraQRPageModule)
  },
  {
    path: 'feriados',
    loadChildren: () => import('./estudiante/feriados/feriados.module').then( m => m.FeriadosPageModule)
  },
  {
    path: 'qr',
    loadChildren: () => import('./docente/generador-qr/generador-qr.module').then( m => m.GeneradorQRPageModule)
  },
  {
    path: 'qr-scanner',
    loadChildren: () => import('./estudiante/qr-scanner/qr-scanner.module').then( m => m.QrScannerPageModule)
  },
  {
    path: 'recuperar',
    loadChildren: () => import('./recuperar/recuperar.module').then( m => m.RecuperarPageModule)
  },
    
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
