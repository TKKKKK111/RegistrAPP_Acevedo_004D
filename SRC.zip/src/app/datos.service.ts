import { Injectable } from '@angular/core';
import { Storage } from '@ionic/storage';
export interface Estudiante{
  userEstudiante: string;
  nomEstudiante: string;
  correoEstudiante: string;
  passEstudiante: string;
  repassEstudiante:string;
}

export interface Asistencia {
  idAsistencia: number;
  fechaAsistencia: string;
  horaAsistencia: string;
  idCurso: number;

}

const USERS_KEY ='my-estudiantes';
const ASISTENCIA_KEY ='my-asistencia';


@Injectable({
  providedIn: 'root'
})
export class DatosService{

  
  private _storage : Storage;
  
  constructor(private storage: Storage) { 
    this.init();
  }


  //creamos el almacen de key,value
  async init(){
    const storage = await this.storage.create();
    this._storage = storage;  
  }



  // Escanear codigo QR y guardar en el storage
  async addAsistencia(dato: Asistencia):Promise<any>{
    return this.storage.get(ASISTENCIA_KEY).then((asistencias: Asistencia[])=>{
      if(asistencias){
        asistencias.push(dato);
        return this.storage.set(ASISTENCIA_KEY, asistencias);
      }else{
        return this.storage.set(ASISTENCIA_KEY, [dato]);
      }
    });
  }
 
     


  //crear un nuevo usuario en el storage
  async addUsuario(dato: Estudiante):Promise<any>{
    return this.storage.get(USERS_KEY).then((datos: Estudiante[])=>{
      if (datos){
          datos.push(dato);
          return this.storage.set(USERS_KEY, datos);
      }
      else{
        return this.storage.set(USERS_KEY, [dato]);
      }
     })
  }//fin del método add

  //obtener los usuarios del storage
  async getUsuarios(){
    return this.storage.get(USERS_KEY);
   
  }
  async getAsistencias(){
    return this.storage.get(ASISTENCIA_KEY);
  }
  
}