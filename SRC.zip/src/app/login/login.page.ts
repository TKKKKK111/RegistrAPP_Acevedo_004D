import { Component, OnInit } from '@angular/core';
import { AlertController, NavController } from '@ionic/angular';
import { 
  FormGroup,
  FormControl,
  Validators,
  FormBuilder
} from '@angular/forms';
import { RouterLink } from '@angular/router';
import { DatosService, Estudiante } from '../datos.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  valuefromuser: any;
  formularioLogin: FormGroup;
  usuarios : Estudiante[] = [];

  constructor(private alertController: AlertController,
              private navController: NavController, 
              private registroService: DatosService, 
              private fb: FormBuilder) { 
                  this.formularioLogin = this.fb.group({
                    'user' : new FormControl("", [Validators.required,Validators.minLength(4),Validators.maxLength(8)]),
                    'password': new FormControl("", [Validators.required,Validators.minLength(4),Validators.maxLength(10)])
                  })
              }

  ngOnInit() {
  }
  
  //busca el correo y password en el storage  
  async Ingresar(){
    var f = this.formularioLogin.value;
    var a=0;
  

    this.registroService.getUsuarios().then(async datos=>{ 
      this.usuarios = datos;
      if (!datos || datos.length==0)
      {
        return null; 
      }
       

       
        
      for (let obj of this.usuarios){
        if (obj.userEstudiante == f.user && obj.passEstudiante==f.password){
         

         
          this.valuefromuser = obj.nomEstudiante;
          this.alertaIngreso();

            
          
          
         
          a=1;

          localStorage.setItem('ingresado', 'true');//almacena localmente el estado de ingresado
          this.navController.navigateRoot('estudiante/inicio');
          
        }
        
      }
      if (a==0){
        this.alertMsg();
      }
    })
  }
  
 
  // alerta de ingreso correcto con nombre de usuario 
  async alertaIngreso(){
    const alert = await this.alertController.create({
      header: 'Ingreso Correcto',
      message: 'Bienvenido '+' ' +this.valuefromuser,
      buttons: ['OK']
    });
    await alert.present();
  }




  async alerta (){
    const alert = await this.alertController.create({
      header:'Bienvenido' ,
      buttons: ['Aceptar']
    })
    await alert.present();
  }





  async alertMsg(){
    const alert = await this.alertController.create({
      header: 'Error..',
      message: '¡El usuario ingresado no existe',
      buttons: ['Aceptar'],
    });
    await alert.present();
  }//findelmetodo
  
  }




